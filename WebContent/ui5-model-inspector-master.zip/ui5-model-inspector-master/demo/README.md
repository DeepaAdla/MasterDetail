# Demo Application
### https://mitch-b.github.io/ui5-model-inspector/demo/

This application is the Manage Products demo application found on OpenUI5 site.

The application has been slightly modified to use the MockServer by default.
